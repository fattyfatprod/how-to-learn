
Учебный проект-Научиться учиться
by Yandex Practicum


Описание:
Учебный проект от компании Яндекс Практикум 
Профессия: Веб-разработчик

Технологии:
HTML
CSS
БЭМ (Nested)
GIT
Функциональность:
Использование HTML тегов ( header, footer, section, h1, main, nav, )
Построение сеток с помощью флексов
Структура папок (каждый блок находится в отдельной папке)
Использование анимации @keyframes
Использование методологии БЭМ
block__element_modificator

Project-https://github.com/fattyfatprod/how-to-learn/blob/main/how-to-learn.zip
